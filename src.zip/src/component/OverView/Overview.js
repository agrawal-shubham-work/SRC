import React from 'react';
import './overview.css';
import calender from "../../assets/images/calender.svg";
import Dropdown from '../DropDown/dropdown';
import BreadCum from '../BreadCum/BreadCum';

class OverView extends React.Component {
  
  
   constructor(props){
   super(props);
   this.state = {
    weeks: ['Week1','Week2','Week3'],
    Platform: ['Hp'],
    Countries: ['India','Australia','Malayasisa'],
    SellerType: ['Amazon','eBuy','Flipkart'],
    BreadCumData: ['Product Availbility','WorldWide Overview'],

   }
 }
    render() {
        return (
       <div className="navbarContent">
              <div id="selectDates">
                <div className="cal_week">
                  <img src={calender}  alt="Calender"/>                  
                  <Dropdown data={this.state.weeks} label='Weekly' ></Dropdown>
                
                 </div>
                 <div id="categories">
                  <p>Filter by: </p> 
                  
                  <Dropdown data={this.state.Countries} label='All Countries' className="cal_cmp"></Dropdown> 

                  <Dropdown  className="" data={this.state.Platform} label='All Platform'></Dropdown>
                  <Dropdown data={this.state.SellerType} label="All Categories" className=""></Dropdown>

                  <Dropdown data={this.state.SellerType} label="All SellerType" className=""></Dropdown> 
                </div>
              </div>
              <div id="path_content">

                <BreadCum className="path_content_active"  BreadCumData = {this.state.BreadCumData}/> 
              </div>
            </div>

        );
    }

}

export default OverView;