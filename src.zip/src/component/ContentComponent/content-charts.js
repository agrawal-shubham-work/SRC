import React from "react";
import Grid from "@material-ui/core/Grid";
import ProductAvailablityCard from "./product-availablity-card";
import ProductAvailablityOverViewChart from "./chartscomponets/product-availablity-overview-chart";
import ProductAvailablityTrendChart from "./chartscomponets/product-availablity-trend-chart";
import "./content-charts.css";
import { countryData, companyData } from "./product-percentage-data";
import ProductPercentageBody from "./chartscomponets/product-percentage-body";

export default function ContentChart() {
  //This will be a state connected to redux
  const category = "WorldWide";

  return (
    <Grid container className="content-container">
      {/*above chart container*/}
      <Grid container item xs={12}>
        <Grid item md={6} xs={12}>
          <ProductAvailablityCard
            title={"Product Availability " + category}
            subTitle={"By All Categories"}
            tooltipData={"This is WorldWide Chart Container"}
            chartComponent={<ProductAvailablityOverViewChart />}
          />
        </Grid>
        <Grid item md={6} xs={12}>
          <ProductAvailablityCard
            title={"Product Availability Trend " + category}
            subTitle={"By All Categories"}
            tooltipData={"This is WorldWide Trend Chart Container"}
            chartComponent={<ProductAvailablityTrendChart />}
          />
        </Grid>
      </Grid>

      {/*Below chart Container */}
      <Grid container item xs={12}>
        {/* <ProductAvailablityCard /> Write Component name, use rightContainer prop to add low-to-high filter */}
        <Grid item md={6} xs={12}>
          <ProductAvailablityCard
            title={"Product Availability Per Country"}
            subTitle={"By All Categories"}
            showDropdown="true"
            chartComponent={
              <ProductPercentageBody data={countryData} arrow="show" />
            }
          />
        </Grid>
        <Grid item md={6} xs={12}>
          <ProductAvailablityCard
            title={"Product Availability Per Platform"}
            subTitle={"By All Countries | All Categories"}
            showDropdown="true"
            chartComponent={
              <ProductPercentageBody data={companyData} arrow="disable" />
            }
          />
        </Grid>
      </Grid>
    </Grid>
  );
}
