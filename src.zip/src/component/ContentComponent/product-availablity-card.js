import React from "react";
import { Paper, Tooltip } from "@material-ui/core";
import TooltipIconImage from '../../assets/Icon/KpiButtonTooltipIcon.png'
import "./content-charts.css";
import Dropdown from "./chartscomponets/dropdown.js";

export default function ProductAvailablityCard(props) {
  var dropdownArray = ["Low To High", "High To Low"];

  return (
    <Paper className="chart-card">
      <div className="chart-card-header">
        <div className="chart-card-title-container">
          <span className="chart-card-title">{props.title}</span>
          {props.tooltipData ? (
            <Tooltip title={props.tooltipData}>
              <img src={TooltipIconImage} style={{width:'16px',height:'16px',margin:'auto 16px',justifyContent:'center'}} alt='Tooltip' />
            </Tooltip>
          ) : null}
        </div>
        {props.showDropdown === "true" ? (
          <Dropdown values={dropdownArray}></Dropdown>
        ) : null}
        <div className="chart-card-subtitle-container">
          <span className="chart-card-subtitle">{props.subTitle}</span>
        </div>
      </div>
      {props.chartComponent}
    </Paper>
  );
}
