import React from "react";
import "../content-charts.css";
import { Divider } from "@material-ui/core";
import { abbreviateNumber } from "../utils";

export default function ProductAvailablityOverViewChart(props) {
  //This will be a state connected to redux
  const inStockPercentage = 56;
  const outStockPercentage = 34;
  const unlistedPercentage = 10;
  const numberOfProducts = 12647;
  return (
    <div className="chart-grey-container" style={{ padding: "26px 15px" }}>
      <div style={{ flexDirection: "row", flex: 1, display: "flex" }}>
        <div
          className="stacked-chart"
          style={{
            width: "56%",
            borderTopRightRadius: 0,
            borderBottomRightRadius: 0,
          }}
        />

        <div
          className="stacked-chart"
          style={{
            width: "44%",
            background: "#EB4563",
            borderTopLeftRadius: 0,
            borderBottomLeftRadius: 0,
          }}
        />
      </div>
      <Divider />
      <div className="stacked-chart-details-container">
        <ChartDetailsContainer
          indicatorColor={"#1D3557"}
          title="In Stock"
          numberOfProducts={numberOfProducts}
          percentage={inStockPercentage}
        />
        <ChartDetailsContainer
          indicatorColor={"#EB4563"}
          title="Out of Stock"
          numberOfProducts={numberOfProducts}
          percentage={outStockPercentage}
        />
      </div>
    </div>
  );
}

function ChartDetailsContainer(props) {
  return (
    <div className="stacked-chart-details-item">
      <div className="stacked-chart-details-item-header">
        <div
          className="stacked-chart-indicator-circle"
          style={{ background: props.indicatorColor }}
        />
        <span className="stacked-chart-details-item-header-title">
          {props.title}
        </span>
      </div>
      <div className="stacked-chart-details-item-percentage">
        {props.percentage}%
      </div>
      <div className="stacked-chart-details-item-products">
        {abbreviateNumber(props.numberOfProducts, 1) + " Products"}
      </div>
    </div>
  );
}
