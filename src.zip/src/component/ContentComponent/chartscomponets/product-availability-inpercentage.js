import React from "react";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";

export default function ProductAvailabilityInpercentage(props) {
  var setWidth = props.arrowProperty ? "95%" : "100%";
  var setMargin = props.arrowProperty ? "-2px" : "8px";

  return (
    <div className="percentage-tab">
      <div style={{ width: setWidth }}>
        <p style={{ margin: "0", marginBottom: setMargin, float: "left" }}>
          {props.name}
        </p>
        <p style={{ float: "right", margin: "0", marginBottom: setMargin }}>
          {props.percentage}
        </p>
        {props.arrowProperty ? (
          <ChevronRightIcon
            className="material-icons"
            style={{ float: "right" }}
          />
        ) : null}
        <div className="percentage-line" style={{ clear: "both" }}>
          <div
            style={{
              height: "100%",
              width: `${props.percentage}`,
              backgroundColor: "rgb(29, 53, 87)",
            }}
          ></div>
        </div>
      </div>
    </div>
  );
}
