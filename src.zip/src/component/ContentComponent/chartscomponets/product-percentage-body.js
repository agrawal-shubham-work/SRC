import React from "react";
import ProductAvailabilityInpercentage from "./product-availability-inpercentage.js";

export default function ProductPercentageBody(props) {
  var showArrow = props.arrow === "show" ? true : false;
  return (
    <div className="chart-grey-container" style={{ height: 250 }}>
      {props.data.map((items) => (
        <ProductAvailabilityInpercentage
          key={items.name}
          name={items.name}
          percentage={items.percentage}
          arrowProperty={showArrow}
        ></ProductAvailabilityInpercentage>
      ))}
    </div>
  );
}
