import React from "react";
import "../content-charts.css";
//import { Chart } from "react-google-charts";
import {
  LineChart,
  Line,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Label,
  CartesianGrid,
  Tooltip,
  
} from "recharts";

const data = [
  {
    name: "Week01",
    "In Stock": 50,
    "Out Stock": 30,
  },
  {
    name: "Week02",
    "In Stock": 70,
    "Out Stock": 40,
  },
  {
    name: "Week03",
    "In Stock": 20,
    "Out Stock": 50,
  },
  {
    name: "Week04",
    "In Stock": 56,
    "Out Stock": 34,
  },
];

export default function ProductAvailablityOverViewChart(props) {
  //This will be a state connected to redux
  return (
    <div className="chart-grey-container">
      <ResponsiveContainer width={"100%"} height={265}>
        <LineChart data={data}>
          <CartesianGrid strokeOpacity={0.3} />
          <XAxis dataKey="name" stroke={0.3} tickMargin={2}>
            <Label value="SKU Names" position="insideBottom" />
          </XAxis>

          <YAxis
            tickFormatter={(tickItem) => {
              return tickItem.toString() + "%";
            }}
          >
            <Label
              style={{ textAnchor: "middle" }}
              value="Number of products"
              position="insideLeft"
              offset={10}
              angle={-90}
            />
          </YAxis>
          <Tooltip
            wrapperStyle={{ borderRadius: 10 }}
            formatter={(value, name, props) => {
              return value.toString() + "%";
            }}
          />

          <Line
            type="monotone"
            dataKey="In Stock"
            stroke="#1D3557"
            strokeWidth={2}
            activeDot={{ r: 8 }}
          />
          <Line
            type="monotone"
            dataKey="Out Stock"
            stroke="#EB4563"
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
      {/* <Chart
        height={"230px"}
        chartType="LineChart"
        loader={<div>Loading Chart</div>}
        data={[
          ["x", "dogs", "cats"],
          [0, 0, 0],
          [1, 10, 5],
          [2, 23, 15],
          [3, 17, 9],
          [4, 18, 10],
          [5, 9, 5],
          [6, 11, 3],
          [7, 27, 19],
        ]}
        options={{
          backgroundColor: "transparent",
          colors: ["#1D3557", "#EB4563"],
          hAxis: {
            title: "SKU Names",
          },
          vAxis: {
            title: "Number of Sellers",
          },

          is3D: true,
          legend: false,
          series: {
            0: { curveType: "function" },
            1: { curveType: "function" },
          },
        }}
      /> */}
    </div>
  );
}
