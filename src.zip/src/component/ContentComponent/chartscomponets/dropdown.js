import React from "react";

export default function Dropdown(props)
{
    return(
        <div className="dropdown">
            <p style={{float:"left"}}>Sort By:</p>
            <select style={{float:"left"}} >
                {props.values.map(items=><option>{items}</option>)}
            </select>
        </div>
    )
}