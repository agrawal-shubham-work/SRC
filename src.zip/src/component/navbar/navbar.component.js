import React from 'react';

import "./navbar.component.css";
import hpLogo from "../../assets/images/hpLogo.png";

import {  NavLink } from 'react-router-dom';



const NavBar = (props) => {

    return(

        <div className="navbar">
            <div className="header">
                <div id="brand_logo">
                  <img src={hpLogo} alt="Hp Logo" />
                  <p id="brand_label">Digital Shelf</p>
                </div>
                <div id="header_items">
                  <div className="header_item header_item_active"><NavLink to={{
                                pathname: '/overview',
                              
                              
                            }}>OverView</NavLink></div>
                  <div className="header_item"><NavLink to={{
                                pathname: '/Competatior-Analysis',
                               
                               
                            }}>Competatior Analysis</NavLink></div>
                  <div className="header_item"><NavLink to={{
                                pathname: '/Promotional-Analysis',
                                hash: '#submit',
                                search: '?quick-submit=true'
                            }} >Promotional Analysis</NavLink></div>
                </div>
           
            </div>
            {/* <Route path="/overview" exact component={Overview} />
            <Route path="/Competatior-Analysis" exact component={BrandRegistry} />
            <Route path="/Promotional-Analysis" exact component={PromotionAnalysis} /> */}
         
            
       
        </div>
    );

}
export default NavBar;
