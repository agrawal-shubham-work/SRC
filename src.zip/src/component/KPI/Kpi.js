import React, { Component } from 'react';
import classes from './Kpi.module.css';
import KpiTabs from './KpiTabs/KpiTabs';
import {connect} from 'react-redux';
import {setKpiData,onTabSelected} from '../../store/action/kpiAction'


class  Kpi extends Component {

    state={
        HP_DATA : [
          {
           "Availability" : "Yes",
           "Calendar Month" : "May",
           "Calendar Week" : "Wk20",
           "Country" : "India",
           "Date Collected" : "12-05-2020",
           "Listing" : "Yes",
           "Refurbished" : "Original",
           "Seller Name" : "Appario Retail Private Ltd",
           "Seller Rating" : 4.5,
           "Seller Rating(full score)" : 90,
           "Seller Type" : "Authorised Store 3P",
           "Source of marketplace" : "Amazon",
           "Total Price" : 1232,
           "Total Price (USD)" : 16.2471232
         },
          {
           "Availability" : "No",
           "Calendar Month" : "May",
           "Calendar Week" : "Wk20",
           "Country" : "India",
           "Date Collected" : "12-05-2020",
           "Listing" : "Yes",
           "Refurbished" : "Original",
           "Seller Name" : "Appario Retail Private Ltd",
           "Seller Rating" : 4.5,
           "Seller Rating(full score)" : 90,
           "Seller Type" : "Authorised Store 3P",
           "Source of marketplace" : "Amazon",
           "Total Price" : 1232,
           "Total Price (USD)" : 16.2471232
         },
          {
           "Availability" : "No",
           "Calendar Month" : "May",
           "Calendar Week" : "Wk20",
           "Country" : "India",
           "Date Collected" : "12-05-2020",
           "Listing" : "Yes",
           "Refurbished" : "Original",
           "Seller Name" : "Appario Retail Private Ltd",
           "Seller Rating" : 4.5,
           "Seller Rating(full score)" : 90,
           "Seller Type" : "Authorised Store 3P",
           "Source of marketplace" : "Amazon",
           "Total Price" : 1232,
           "Total Price (USD)" : 16.2471232
         }
     
       ]
      }
    

    componentDidMount(){
    
        this.props.onKpiData(this.state.HP_DATA);
    }

    render(){
    
    console.log(this.props.currentUrlPath);

    const tabs=this.props.tabsData.map(data =>{

        console.log('KPI    '+this.props.currentUrlPath + '/' + data.link);

        return (
           
                <KpiTabs 
                        key={data.title}
                        link={this.props.currentUrlPath+'/'+data.link}
                        positiveCheck={data.isPositive}
                        title={data.title} 
                        description={data.toolTipDescription}
                        percentageValue={data.percentageData}
                        percentageSubData={data.percentageSubData}
                        productShortDesc={data.kpiSubData}
                        click={()=>this.props.onTabSelected(this.props.currentUrlPath+'/'+data.link)}

                    />
            
            
        );
    });



    

    return(
    <div style={{padding:'0 20px'}}>
        <div className={classes.Kpi}>
            
            {tabs}
            
    </div>
    </div>
    );
    }
} 
    // let available=0;

    // Object.keys(props.hp_data).map(data =>{
    //     if(props.hp_data[data].Availability === "Yes")
    //     {
    //         available++;
    //     }
    //     return null;
    // });

    // const calculatedProductAvailability=((available/props.hp_data.length)*100).toFixed(0);

    

const mapStateToProps = state => {
        return {
            tabsData:state.kpi.KpiButtonData,
            
        }
}

const mapDispatchToProps = dispatch => {
    return{
        onKpiData : (data) => dispatch(setKpiData(data)),
        onTabSelected:(path)=>dispatch(onTabSelected(path))
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Kpi);