import React from 'react';
import classes from "./KpiTabs.module.css";
import Tooltip from '@material-ui/core/Tooltip';
import { NavLink } from 'react-router-dom';
import TooltipIconImage from '../../../assets/Icon/KpiButtonTooltipIcon.png'
import { connect } from 'react-redux';
import {onTabSelected} from '../../../store/action/kpiAction'

const kpiTabs=(props)=>{
    
    

    return (
        <div className={classes.KpiTabs}>
        <NavLink activeClassName={classes.active} to={props.link}  onClick={props.click} >
        <div className={classes.TabData}>
            <div style={{display:'flex',justifyContent:'space-between'}}>
                <p className={classes.Title}>{props.title}</p>
                <Tooltip title={props.description}>
                    {/* <HelpOutlineIcon style={{width:'16px',height:'16px',margin:'auto 16px',justifyContent:'center'}} /> */}
                    <img src={TooltipIconImage} style={{width:'16px',height:'16px',margin:'auto 16px',justifyContent:'center'}} alt='Tooltip' />
                </Tooltip>
            </div>
            <div style={{display:'flex',margin:'13px 0 0 0'}}>
                <p className={classes.PercentageData}>{props.percentageValue}</p>
                <div style={{backgroundColor:props.positiveCheck? '#06B754':'red',}} className={classes.GreenCircle}></div>
                <p style={{color:props.positiveCheck? '#06B754':'red',marginLeft:'4px'}} className={classes.ProductSubData}>{props.percentageSubData}</p>
            </div>
            <p style={{color:props.positiveCheck? '#06B754':'red',}} className={classes.ShortDataDesc}>{props.productShortDesc}</p>
        </div>
        </NavLink>
    </div>
    );
}



const mapDispatchToProps = dispatch =>{
    return {
        setCurrentKpi : (path) => dispatch(onTabSelected(path))
    }
}

export default connect(null,mapDispatchToProps) (kpiTabs);