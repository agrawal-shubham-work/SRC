import React from 'react';
import downarrow from '../../assets/images/downarrow.svg';

const DownArrow = () => {
    return (
<div>
<img src={downarrow} alt="Down"></img>
</div>
    );
}

export default DownArrow;