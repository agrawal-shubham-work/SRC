import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import DownArrow from '../DropDown/DownArrow';





const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: theme.spacing(2),
      minWidth: 120,
      
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
    
  }));



  function Dropdown(props) {
  const classes = useStyles();
  const [state, setState] = React.useState({
    
  });
 

  const handleChange = (event) => {
    setState({
      ...state,
      
    });
  };

const dropDownOptions=props.data.map(key=>{
    console.log(key);
        return (
    <MenuItem key={key} value={key}>{key}</MenuItem>
    )
  })

        return(
          <FormControl className={classes.formControl}>
          <InputLabel id="internalstyling">{props.label}</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={props.age}
            label={props.label}
            onChange={handleChange}
            
            disableUnderline={true}  
       
            IconComponent={() => (
              <DownArrow />
            )}>
                {dropDownOptions}
              
              
          </Select>
        </FormControl>);
    }
       

export default Dropdown;

