import React from 'react';
import Tooltip from '@material-ui/core/Tooltip';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import TooltipIconImage from '../../assets/Icon/KpiButtonTooltipIcon.png'


const Tooltips = (props) =>{

    const [open, setOpen] = React.useState(false);

    const handleTooltipClose = () => {
        setOpen(false);
    };

    const handleTooltipOpen = () => {
        setOpen(true);
    };

    return (
        <ClickAwayListener onClickAway={handleTooltipClose}>
            <div>
              <Tooltip
                PopperProps={{
                  disablePortal: true,
                }}
                onClose={handleTooltipClose}
                open={open}
                disableFocusListener
                disableHoverListener
                disableTouchListener
                title={props.title}
              >
                <img onClick={handleTooltipOpen} src={TooltipIconImage} style={{width:'16px',height:'16px',margin:'auto 16px',justifyContent:'center'}} alt='Tooltip' />
              </Tooltip>
            </div>
          </ClickAwayListener>
    );
}

export default Tooltips;