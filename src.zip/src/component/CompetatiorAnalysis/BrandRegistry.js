import React,{Component} from 'react';



class BrandRegistry extends React.Component {
    render() {
       return (
          <div>
             <h1>Competatior Analysis...</h1>
          </div>
       )
    }
 }
 export default BrandRegistry;