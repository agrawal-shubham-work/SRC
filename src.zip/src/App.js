import React, { Component } from 'react';
import './App.css';
import RootLayout from './container/RootLayout';
import { BrowserRouter, Route } from "react-router-dom";
import NavBar from "./component/navbar/navbar.component";
import { Provider } from 'react-redux';
import {store} from "./store/store"

class App extends Component {
  render(){
    return (
     
        <BrowserRouter basename="/">
       <Provider store={store}>
         
          <NavBar/>
           <Route path="/overview"  component={RootLayout} /> 
       </Provider>
     </BrowserRouter>
        

     
    );
  }
}

export default App;
// 
