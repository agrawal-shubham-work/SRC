import React from 'react';
import Kpi from '../component/KPI/Kpi';
import ContentChart from '../component/ContentComponent/content-charts';
import { Route,useRouteMatch } from 'react-router-dom';
import Overview from '../component/OverView/Overview'
const RootLayout =(props) =>{

    let { url } = useRouteMatch();

   
    return (
        <React.Fragment>
            <Overview />
            <Kpi currentUrlPath={url} />
            <Route path={url+'/product-availability'} component={ContentChart} />
        </React.Fragment>
    );
}

export default RootLayout;