const intialState={
    KpiButtonData:[
        {
            title:'Product Availability',
            percentageData:'86%',
            isPositive:true,
            percentageSubData:'+6%',
            kpiSubData:'06% increase than last week.',
            toolTipDescription:'Product Availability Desc',
            link:'product-availability'
        },
        {
            title:'Seller Analysis',
            percentageData:'58.2K',
            isPositive:false,
            percentageSubData:'-100',
            kpiSubData:'07% decrease in number of sellers',
            toolTipDescription:'Seller Analysis Desc',
            link:'seller-analysis'
        },
        {
            title:'Price Change',
            percentageData:'32%',
            isPositive:false,
            percentageSubData:'-2%',
            kpiSubData:'60K SKU\'s underwent price change out of 500K SKU\'s',
            toolTipDescription:'Price Change Desc',
            link:'price-change'
        },
        {
            title:'Content Compliance',
            percentageData:'78%',
            isPositive:false,
            percentageSubData:'-12%',
            kpiSubData:'12% less than target 90%',
            toolTipDescription:'Content Compliance Desc',
            link:'content-compliance'
        },
        {
            title:'Share of Search',
            percentageData:'42%',
            isPositive:false,
            percentageSubData:'-5%',
            kpiSubData:'08% less than target 50%',
            toolTipDescription:'Share of Search Desc',
            link:'share-of-search'
        },
        {
            title:'Reviews',
            percentageData:'4.2K',
            isPositive:false,
            percentageSubData:'-1.2K',
            kpiSubData:'20% reviews with less than 4 stars',
            toolTipDescription:'Reviews Desc',
            link:'reviews'
        },
        {
            title:'Ratings',
            percentageData:'3.5',
            isPositive:false,
            percentageSubData:'No Change',
            kpiSubData:'4.3% drop in revenue than last week',
            toolTipDescription:'Ratings Desc',
            link:'ratings'
        }
    ],
    currentKpi:'product-availability'
}

const kpiReducer = (state=intialState,action) =>{
    switch (action.type){
        case 'SET_KPI_DATA':{

            let counter=0;
            let percentageProductAvailability=0;
            const total=action.kpiData.length;

            action.kpiData.map((data) =>{
                if (data.Availability === 'Yes')
                    counter=counter+1;

                return null;
 
            });

            percentageProductAvailability=((counter/total)*100).toFixed(0);


            const newKpiButtonData=[
                {
                    title:'Product Availability',
                    percentageData:percentageProductAvailability+'%',
                    isPositive:true,
                    percentageSubData:'+6%',
                    kpiSubData:counter+' product available in stock.',
                    toolTipDescription:'Product Availability Desc',
                    link:'product-availability'
                },
                {
                    title:'Seller Analysis',
                    percentageData:'58.2K',
                    isPositive:false,
                    percentageSubData:'-100',
                    kpiSubData:'07% decrease in number of sellers',
                    toolTipDescription:'Seller Analysis Desc',
                    link:'seller-analysis'
                },
                {
                    title:'Price Change',
                    percentageData:'32%',
                    isPositive:false,
                    percentageSubData:'-2%',
                    kpiSubData:'60K SKU\'s underwent price change out of 500K SKU\'s',
                    toolTipDescription:'Price Change Desc',
                    link:'price-change'
                },
                {
                    title:'Content Compliance',
                    percentageData:'78%',
                    isPositive:false,
                    percentageSubData:'-12%',
                    kpiSubData:'12% less than target 90%',
                    toolTipDescription:'Content Compliance Desc',
                    link:'content-compliance'
                },
                {
                    title:'Share of Search',
                    percentageData:'42%',
                    isPositive:false,
                    percentageSubData:'-5%',
                    kpiSubData:'08% less than target 50%',
                    toolTipDescription:'Share of Search Desc',
                    link:'share-of-search'
                },
                {
                    title:'Reviews',
                    percentageData:'4.2K',
                    isPositive:false,
                    percentageSubData:'-1.2K',
                    kpiSubData:'20% reviews with less than 4 stars',
                    toolTipDescription:'Reviews Desc',
                    link:'reviews'
                },
                {
                    title:'Ratings',
                    percentageData:'3.5',
                    isPositive:false,
                    percentageSubData:'No Change',
                    kpiSubData:'4.3% drop in revenue than last week',
                    toolTipDescription:'Ratings Desc',
                    link:'ratings'
                }
            ];

            return{
                ...state,
                KpiButtonData:newKpiButtonData,
            }
        }
        case 'SET_PATH':{
            return{
                ...state,
                currentKpi:action.path
            }
        }
        default:{
            return state;
        }
    }
    
}

export default kpiReducer;