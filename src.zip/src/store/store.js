import { createStore, combineReducers, applyMiddleware } from "redux";

import kpiReducer from "./reducer/kpiReducer";

const rootReducer = combineReducers({
  kpi: kpiReducer,
});

export const store = createStore(rootReducer);
