export const setKpiData = (kpiData) =>{
    return{
        type:'SET_KPI_DATA',
        kpiData:kpiData
    }
}

export const onTabSelected = (path) =>{
    return {
        type:'SET_PATH',
        path:path
    }
}